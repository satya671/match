const express = require('express')
const path = require('path')
const dbpath = path.join(__dirname, 'cricketMatchDetails.db')
const {open} = require('sqlite')
const sqlite3 = require('sqlite3')
let db = null
const app = express()
const functionForDataBaseAndServer = async () => {
  try {
    db = await open({
      filename: dbpath,
      driver: sqlite3.Database,
    })
    app.listen(3002, () => {
      console.log('server is running at http://localhost:3000')
    })
  } catch (e) {
    console.log(`DB ERROR: ${e.message}`)
    process.exit(1)
  }
}
const playersList = eachVal => {
  return {
    matchId: eachVal.match_id,
    match: eachVal.match,
    year: eachVal.year,
  }
}
const listOfPlayers7 = eachPlayer => {
  return {
    playerId: eachPlayer.player_id,
    playerName: eachPlayer.player_name,
  }
}
const listOfplayerResponse2 = eachplayerval1 => {
  return {
    playerId: eachplayerval1.player_id,
    playerName: eachplayerval1.player_name,
  }
}

functionForDataBaseAndServer()
app.get('/players/', async (request, response) => {
  const getQuery1 = `SELECT * FROM player_details`
  const response1 = await db.all(getQuery1)
  response.send(
    response1.map(eachplayerval1 => listOfplayerResponse2(eachplayerval1)),
  )
})
app.get('/players/:playerId/', async (request, response) => {
  const {playerId} = request.params
  const getQuery2 = `SELECT * FROM player_details WHERE player_id=${playerId}`
  const response2 = await db.get(getQuery2)
  const dbresponse = {
    playerId: response2.player_id,
    playerName: response2.player_name,
  }
  response.send(dbresponse)
})
app.put('/players/:playerId/', async (request, response) => {
  const {playerId} = request.params
  const playerDetails = request.body
  const {playerName} = playerDetails
  const putQuery = `UPDATE player_details SET player_name='${playerName}' WHERE player_id=${playerId}`
  await db.run(putQuery)
  response.send('Player Details Updated')
})
app.get('/matches/:matchId/', async (request, response) => {
  const {matchId} = request.params
  const getQuery3 = `SELECT * FROM match_details WHERE match_id=${matchId}`
  const response4 = await db.get(getQuery3)
  const dbresponse4 = {
    matchId: response4.match_id,
    match: response4.match,
    year: response4.year,
  }
  response.send(dbresponse4)
})
app.get('/players/:playerId/matches', async (request, response) => {
  const {playerId} = request.params
  const getQuery5 = `SELECT * FROM player_match_score NATURAL JOIN  match_details WHERE player_id=${playerId}`
  const dbResoponse5 = await db.all(getQuery5)
  response.send(dbResoponse5.map(eachval => playersList(eachval)))
})
app.get('/matches/:matchId/players', async (request, response) => {
  const {matchId} = request.params
  const getQuery6 = `SELECT player_details.player_id as playerId, player_details.player_name as playerName FROM player_match_score NATURAL JOIN  player_details WHERE match_id=${matchId}`
  const dbQuery = await db.all(getQuery6)
  response.send(dbQuery.map(eachPlayer => listOfPlayers7(eachPlayer)))
})
app.get('/players/:playerId/playerScores', async (request, response) => {
  const {playerId} = request.params
  const lastGetQuery = `SELECT player_details.player_id as playerId,player_details.player_name as playerName,SUM(player_match_score.score) as totalScore,SUM(player_match_score.fours) as totalFours,SUM(player_match_score.sixes) as totalSixes FROM player_details INNER JOIN player_match_score ON player_details.player_id=player_match_score.player_id WHERE player_match_score.player_id=${playerId}`
  const lastgetResponse = await db.all(lastGetQuery)
  const dbLastResponse = {
    playerId: lastgetResponse.player_id,
    playerName: lastgetResponse.player_name,
    totalScore: lastgetResponse.score,
    totalFours: lastgetResponse.fours,
    totalSixes: lastgetResponse.sixes,
  }
  response.send(dbLastResponse)
})
module.exports = app
